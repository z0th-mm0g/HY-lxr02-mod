/*
 * BeatRepeat.h
 *
 * Tempo-synced beat repeat / stutter for the FX bus.
 * Part of the "Heal Youth" modified firmware for the Erica Synths LXR-02.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * This file is part of a modified version of the LXR firmware. It is licensed
 * under the GNU General Public License version 3, with the additional
 * permission and terms in NOTICE.md. See LICENSE and NOTICE.md in the root of
 * the repository.
 *
 * How it works
 *  - The FX bus input is written continuously into a stereo ring buffer.
 *  - On every sequencer step the effect rolls a dice against "chance".
 *    If it wins and nothing is repeating yet, it records one slice
 *    (length = "len", synced to the tempo) while letting the live signal through,
 *    then loops that slice.
 *  - If the dice loses on a later step, it returns to the live signal.
 *  - Each time the slice loops it can get shorter ("shrink") and change pitch
 *    ("pitch"), which gives the accelerating, pitch-dropping rolls typical of IDM.
 *  - Modes: fwd (forward), rev (reversed slice), rnd (random length,
 *    direction and pitch on every capture).
 */

#ifndef BEATREPEAT_H_
#define BEATREPEAT_H_

#include <stdint.h>

#ifndef FXSAMPLE_T
#define FXSAMPLE_T __fp16
#endif

enum BeatRepeatModeEnum
{
	REPEAT_FWD,
	REPEAT_REV,
	REPEAT_RND,
	NUM_REPEAT_MODES
};

enum BeatRepeatStateEnum
{
	REPEAT_IDLE,
	REPEAT_CAPTURE,
	REPEAT_PLAY
};

#define REPEAT_NUM_DIVISIONS 9

typedef struct BeatRepeatStruct
{
	FXSAMPLE_T *buf;		/**< ring buffer, left half = L, right half = R */
	uint32_t half;			/**< samples per channel (power of 2) */
	uint32_t mask;

	uint8_t mode;			/**< REPEAT_FWD / REV / RND */
	uint8_t state;
	volatile uint8_t pendingSteps;	/**< incremented by the sequencer */
	uint8_t reverse;		/**< reverse playback of the current slice */
	uint8_t divIdx;			/**< current length division */

	float rateParam;		/**< P1 0..1 -> division */
	float chanceParam;		/**< P2 0..1 -> chance per step */
	float pitchParam;		/**< P3 0..1, 0.5 = no pitch change */
	float shrinkParam;		/**< P4 0..1 -> slice shrinks each loop */

	uint32_t write;			/**< write index (per channel) */
	uint32_t start;			/**< slice start index */
	uint32_t baseLen;		/**< captured slice length in samples */
	uint32_t captured;		/**< samples captured so far */
	float curLen;			/**< current loop length (shrinks) */
	float phase;			/**< read position inside the loop */
	float speed;			/**< read increment (pitch) */
	float speedStep;		/**< speed multiplier per loop */
	float shrink;			/**< length multiplier per loop */
	float mix;				/**< 0 = live, 1 = repeat, smoothed */
	uint8_t sliceValid;

	float dcInL, dcOutL, dcInR, dcOutR;	/**< DC blocker: very short loops can sit off-centre */

	uint32_t samplesSinceStep;	/**< internal clock when the sequencer is stopped */
} BeatRepeat;

void BeatRepeat_init(BeatRepeat *r, FXSAMPLE_T *buffer, uint32_t samplesPerChannel);

/** call once per sequencer step (1/16). Safe to call from an interrupt. */
void BeatRepeat_onStep(BeatRepeat *r);

void BeatRepeat_setRate(BeatRepeat *r, float p);
void BeatRepeat_setChance(BeatRepeat *r, float p);
void BeatRepeat_setPitch(BeatRepeat *r, float p);
void BeatRepeat_setShrink(BeatRepeat *r, float p);
void BeatRepeat_setMode(BeatRepeat *r, uint8_t mode);

/**
 * process one block.
 * fxBuffer: interleaved stereo bus input (size frames)
 * out:      interleaved output buffer, the result is ADDED to it (like the other FX)
 * channels: 2 = stereo output, 1 = mono output (written to out[2*i])
 * bpm:      current tempo
 * seqRunning: if 0, an internal 1/16 clock is used instead of the sequencer steps
 */
void BeatRepeat_process(BeatRepeat *r, const int16_t *fxBuffer, int16_t *out, uint16_t size,
		uint8_t channels, float dryWet, float bpm, uint8_t seqRunning);

#endif /* BEATREPEAT_H_ */
