/*
 * Bitcrush.h
 *
 * Bit depth + sample rate reduction for the FX bus, with random jitter.
 * Part of the "Heal Youth" modified firmware for the Erica Synths LXR-02.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * This file is part of a modified version of the LXR firmware. It is licensed
 * under the GNU General Public License version 3, with the additional
 * permission and terms in NOTICE.md. See LICENSE and NOTICE.md in the root of
 * the repository.
 */

#ifndef BITCRUSH_H_
#define BITCRUSH_H_

#include <stdint.h>

typedef struct BitcrushStruct
{
	float step;			/**< quantisation step (1 = 16 bit) */
	float rate;			/**< sample hold increment, 1 = full rate */
	float jitter;		/**< 0..1 random variation of the hold time */
	float gain;			/**< output gain */
	float phase;
	float inc;
	int16_t holdL;
	int16_t holdR;
} Bitcrush;

void Bitcrush_init(Bitcrush *b);
void Bitcrush_setBits(Bitcrush *b, float p);		/**< P1: 0 = 16 bit ... 1 = 1 bit */
void Bitcrush_setDownsample(Bitcrush *b, float p);	/**< P2: 0 = full rate ... 1 = ~650 Hz */
void Bitcrush_setJitter(Bitcrush *b, float p);		/**< P3: random hold time */
void Bitcrush_setGain(Bitcrush *b, float p);		/**< P4: 0..2, 0.5 = unity */

void Bitcrush_process(Bitcrush *b, const int16_t *fxBuffer, int16_t *out, uint16_t size,
		uint8_t channels, float dryWet);

#endif /* BITCRUSH_H_ */
