/*
 * FxBus.c
 *
 *  Created on: 26.08.2020
 *      Author: julian
 *
 * Copyright (C) 2012-2026 Erica Synths
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * This file is part of the LXR firmware. It is licensed under the GNU General
 * Public License version 3, with the additional permission and terms in
 * NOTICE.md. See LICENSE and NOTICE.md in the root of the repository.
 */


#include "Soundengine/FxBus.h"
#include "Soundengine/DSPAudio/BufferTools.h"
#include "Soundengine/DSPAudio/mixer.h"
#include "Soundengine/Sequencer/sequencer.h"
#include <string.h>
INDTCMZ FxBus fxBus;

void FxBus_init()
{
	fxBus.dryWet = 0;
	fxBus.audioRouting = 0;
	fxBus.fxType = FX_OFF;

	fxBus.delay.delayType = DELAY_NORMAL;

	Distortion_init(&fxBus.distortion);
	Ringmod_init(&fxBus.ringmod);
	Compressor_init(&fxBus.compressor);
	Delay_init(&fxBus.delay);
	BeatRepeat_init(&fxBus.repeat, FX_BUFFER, (FX_BUFFER_SIZE+1)/2);
	Bitcrush_init(&fxBus.crush);



#if USE_REVERB
	Reverb_init(&fxBus.reverb);
#endif
}

IN_ITCM_RAM void FxBus_process(int16_t *fxBuffer, int16_t* outL,int16_t* outR,int16_t* outL2, int16_t* outR2, uint32_t size)
{
	int16_t* out;
	int16_t* out2 = NULL;
	// < MIXER_ROUTING_DAC1_L -> stereo 1 or 2
	const uint8_t channels = fxBus.audioRouting < MIXER_ROUTING_DAC1_L ? 2 : 1;
	switch(fxBus.audioRouting)
	{
	default:
	case MIXER_ROUTING_DAC1_STEREO:
		out = outL2;
		out2 = outR2;
		break;
	case MIXER_ROUTING_DAC2_STEREO:
		out = outL;
		out2 = outR;
		break;
	case MIXER_ROUTING_DAC1_L:
		out = outL2;
		break;
	case MIXER_ROUTING_DAC1_R:
		out = outR2;
		break;
	case MIXER_ROUTING_DAC2_L:
		out = outL;
		break;
	case MIXER_ROUTING_DAC2_R:
		out = outR;
		break;

	}

	switch(fxBus.fxType)
	{
	default:
	case FX_OFF:
	{
		if(channels == 2)
		{
			int32_t* stereoIn = (int32_t*)fxBuffer;
			int32_t* stereoOut = (int32_t*)out;

			for(uint8_t i=0;i<size;i++)
			{
				//add stereo samples using SIMD
				*stereoOut = __QADD16(*stereoOut, *stereoIn);
				stereoOut++;
				stereoIn++;
			}
		}
		else
		{
			int32_t* in = (int32_t*)fxBuffer;
			for(uint8_t i=0;i<size;i++)
			{
				*out =  __QADD16(*out, *in);
				out +=2;
				in++;

			}
		}
	}
	break;

	case FX_DISTORTION:
		Distortion_process(&fxBus.distortion, fxBuffer, out, out2, size, channels, fxBus.dryWet);
		break;

	case FX_RING:
		Ringmod_process(&fxBus.ringmod, fxBuffer, out, out2, size, channels, fxBus.dryWet);
		break;

	case FX_COMPRESSOR:
		Compressor_process(&fxBus.compressor, fxBuffer, out, out2, size, channels, fxBus.dryWet);
		break;

	case FX_DELAY:
		if(fxBus.delay.delayType == DELAY_NORMAL)
		{
			Delay_process(&fxBus.delay, fxBuffer, out, out2, size, channels, fxBus.dryWet);
		}
		else
		{
			Delay_processPingPong(&fxBus.delay, fxBuffer, out, out2, size, channels, fxBus.dryWet);
		}
		break;

	case FX_REPEAT:
		BeatRepeat_process(&fxBus.repeat, fxBuffer, out, size, channels, fxBus.dryWet, (float)seq_getBpm(), seq_isRunning());
		break;

	case FX_CRUSH:
		Bitcrush_process(&fxBus.crush, fxBuffer, out, size, channels, fxBus.dryWet);
		break;
#if USE_REVERB
	case FX_REVERB:
		Reverb_process(&fxBus.reverb, fxBuffer, out, out2, size, channels, fxBus.dryWet);
		break;
#endif

	}

}

void FxBus_prepareFxChange()
{
	// Heal Youth mod: delay and beat repeat share FX_BUFFER with different layouts.
	// Clear it and reset the repeat so switching never plays back stale audio.
	const uint8_t repeatMode = fxBus.repeat.mode;
	memset(FX_BUFFER, 0, sizeof(FX_BUFFER));
	BeatRepeat_init(&fxBus.repeat, FX_BUFFER, (FX_BUFFER_SIZE+1)/2);
	BeatRepeat_setRate(&fxBus.repeat, fxBus.parameter[0]);
	BeatRepeat_setChance(&fxBus.repeat, fxBus.parameter[1]);
	BeatRepeat_setPitch(&fxBus.repeat, fxBus.parameter[2]);
	BeatRepeat_setShrink(&fxBus.repeat, fxBus.parameter[3]);
	BeatRepeat_setMode(&fxBus.repeat, repeatMode);
}

void FxBus_onSeqStep()
{
	if(fxBus.fxType == FX_REPEAT)
		BeatRepeat_onStep(&fxBus.repeat);
}

IN_ITCM_RAM void FxBus_updateParameter()
{
	switch(fxBus.fxType)
	{
	case FX_OFF:

		break;

	case FX_DISTORTION:
		Distortion_setDrive(&fxBus.distortion, fxBus.parameter[0] );
		Distortion_setParam1(&fxBus.distortion, fxBus.parameter[1] );
		Distortion_setParam2(&fxBus.distortion, fxBus.parameter[2] );
		Distortion_setParam3(&fxBus.distortion, fxBus.parameter[3] );
		break;

	case FX_RING:
		Ringmod_setFreq(&fxBus.ringmod, fxBus.parameter[0] );
		//Ringmod_setWave(&fxBus.ringmod, fxBus.parameter[1] );
		break;

	case FX_COMPRESSOR:

		Compressor_setAttack(&fxBus.compressor , fxBus.parameter[0]);
		Compressor_setRelease(&fxBus.compressor , fxBus.parameter[1]);
		Compressor_setTreshold(&fxBus.compressor , fxBus.parameter[2]);
		Compressor_setGain(&fxBus.compressor , fxBus.parameter[3]);
		break;

	case FX_DELAY:
		Delay_setRange(&fxBus.delay, fxBus.parameter[1]);
		Delay_setDelayTime(&fxBus.delay, fxBus.parameter[0]);
		Delay_setFilter(&fxBus.delay, fxBus.parameter[2]);
		Delay_setFeedback(&fxBus.delay, fxBus.parameter[3]);

		break;

	case FX_REPEAT:
		BeatRepeat_setRate(&fxBus.repeat, fxBus.parameter[0]);
		BeatRepeat_setChance(&fxBus.repeat, fxBus.parameter[1]);
		BeatRepeat_setPitch(&fxBus.repeat, fxBus.parameter[2]);
		BeatRepeat_setShrink(&fxBus.repeat, fxBus.parameter[3]);
		break;

	case FX_CRUSH:
		Bitcrush_setBits(&fxBus.crush, fxBus.parameter[0]);
		Bitcrush_setDownsample(&fxBus.crush, fxBus.parameter[1]);
		Bitcrush_setJitter(&fxBus.crush, fxBus.parameter[2]);
		Bitcrush_setGain(&fxBus.crush, fxBus.parameter[3]);
		break;
#if USE_REVERB
	case FX_REVERB:
		Reverb_setDelayTime(&fxBus.reverb, fxBus.parameter[0]);
		Reverb_setFeedback(&fxBus.reverb, fxBus.parameter[1]);
		Reverb_setComposition(&fxBus.reverb, fxBus.parameter[2]);

		Reverb_setVariation(&fxBus.reverb, fxBus.parameter[3]);
		break;
#endif
	default:
		break;
	}
}

IN_ITCM_RAM void FxBus_setParameter(uint8_t idx, float value)
{
	fxBus.parameter[idx] = value;

	FxBus_updateParameter();


}


