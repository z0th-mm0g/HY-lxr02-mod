/*
 * BeatRepeat.c
 *
 * Tempo-synced beat repeat / stutter for the FX bus. See BeatRepeat.h.
 * Part of the "Heal Youth" modified firmware for the Erica Synths LXR-02.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * This file is part of a modified version of the LXR firmware. It is licensed
 * under the GNU General Public License version 3, with the additional
 * permission and terms in NOTICE.md. See LICENSE and NOTICE.md in the root of
 * the repository.
 */

#include "Soundengine/DSPAudio/FX/BeatRepeat.h"
#include <math.h>

#ifdef HOST_TEST
#define REAL_FS 44140.f
#else
#include "Soundengine/config.h"
#endif

uint32_t GetRngValue();

/** slice lengths in 1/16 steps: 1/4, 1/8, 1/8T, 1/16, 1/16T, 1/32, 1/32T, 1/64, 1/128 */
static const float repeat_divisions[REPEAT_NUM_DIVISIONS] =
{
	4.f, 2.f, 4.f/3.f, 1.f, 2.f/3.f, 0.5f, 1.f/3.f, 0.25f, 0.125f
};

#define REPEAT_MIN_LEN		32.f	/**< shortest loop in samples (~0.7 ms, becomes a tone) */
#define REPEAT_FADE			32.f	/**< fade at the slice edges against clicks */
#define REPEAT_MIX_STEP		(1.f/64.f)	/**< live <-> repeat crossfade per sample */
#define REPEAT_MIN_SPEED	0.5f	/**< HY3: total pitch limited to -1 octave ... */
#define REPEAT_MAX_SPEED	2.f		/**< ... +1 octave (was 2 octaves) */
#define REPEAT_MAX_SEMIS_PER_LOOP	2.f	/**< HY3: was 7 */

//-----------------------------------------------------------------------
static inline int16_t br_sat16(int32_t x)
{
	if(x > 32767) return 32767;
	if(x < -32768) return -32768;
	return (int16_t)x;
}
//-----------------------------------------------------------------------
static inline float br_rnd01()
{
	return (GetRngValue() % 10000) / 10000.f;
}
//-----------------------------------------------------------------------
static uint8_t br_paramToDiv(float p)
{
	int idx = (int)(p * (REPEAT_NUM_DIVISIONS - 0.001f));
	if(idx < 0) idx = 0;
	if(idx >= REPEAT_NUM_DIVISIONS) idx = REPEAT_NUM_DIVISIONS - 1;
	return (uint8_t)idx;
}
//-----------------------------------------------------------------------
// HY3: gentler pitch. Semitones per loop for the knob: centre (59..68) = 0,
// quadratic curve so the area near the centre is fine-grained, +-2 at the ends.
static float br_semisFromParam(float p)
{
	const float offset = p - 0.5f;
	const float dead = 0.04f;
	if(fabsf(offset) < dead) return 0.f;
	float x = (fabsf(offset) - dead) / (0.5f - dead);	// 0..1
	float semis = x * x * REPEAT_MAX_SEMIS_PER_LOOP;
	return offset < 0.f ? -semis : semis;
}
static float br_pitchStepFromParam(float p)
{
	return powf(2.f, br_semisFromParam(p) / 12.f);
}
//-----------------------------------------------------------------------
static float br_shrinkFromParam(float p)
{
	return 1.f - p * 0.5f;	// 1 = constant length, 0.5 = halves every loop
}
//-----------------------------------------------------------------------
static float br_samplesPerStep(float bpm)
{
	if(bpm < 20.f) bpm = 20.f;
	return REAL_FS * 60.f / bpm / 4.f;
}
//-----------------------------------------------------------------------
static uint32_t br_lenForDiv(BeatRepeat *r, uint8_t div, float bpm)
{
	float len = br_samplesPerStep(bpm) * repeat_divisions[div];
	const float maxLen = (float)(r->half - 64);
	if(len > maxLen) len = maxLen;
	if(len < REPEAT_MIN_LEN) len = REPEAT_MIN_LEN;
	return (uint32_t)len;
}
//-----------------------------------------------------------------------
void BeatRepeat_init(BeatRepeat *r, FXSAMPLE_T *buffer, uint32_t samplesPerChannel)
{
	r->buf = buffer;
	r->half = samplesPerChannel;
	r->mask = samplesPerChannel - 1;
	r->mode = REPEAT_FWD;
	r->state = REPEAT_IDLE;
	r->pendingSteps = 0;
	r->reverse = 0;
	r->divIdx = 3;
	r->rateParam = 3.f / REPEAT_NUM_DIVISIONS;
	r->chanceParam = 0.f;
	r->pitchParam = 0.5f;
	r->shrinkParam = 0.f;
	r->write = 0;
	r->start = 0;
	r->baseLen = 1000;
	r->captured = 0;
	r->curLen = 1000.f;
	r->phase = 0.f;
	r->speed = 1.f;
	r->speedStep = 1.f;
	r->shrink = 1.f;
	r->mix = 0.f;
	r->sliceValid = 0;
	r->samplesSinceStep = 0;
	r->dcInL = r->dcOutL = r->dcInR = r->dcOutR = 0.f;
}
//-----------------------------------------------------------------------
void BeatRepeat_onStep(BeatRepeat *r)
{
	if(r->pendingSteps < 255) r->pendingSteps++;
}
//-----------------------------------------------------------------------
void BeatRepeat_setRate(BeatRepeat *r, float p)		{ r->rateParam = p; }
void BeatRepeat_setChance(BeatRepeat *r, float p)	{ r->chanceParam = p; }
void BeatRepeat_setPitch(BeatRepeat *r, float p)	{ r->pitchParam = p; }
void BeatRepeat_setShrink(BeatRepeat *r, float p)	{ r->shrinkParam = p; }
void BeatRepeat_setMode(BeatRepeat *r, uint8_t mode)
{
	r->mode = (mode < NUM_REPEAT_MODES) ? mode : REPEAT_FWD;
}
//-----------------------------------------------------------------------
static void br_startCapture(BeatRepeat *r, float bpm)
{
	const uint8_t baseDiv = br_paramToDiv(r->rateParam);
	r->speed = 1.f;
	r->phase = 0.f;

	if(r->mode == REPEAT_RND)
	{
		// random length between the chosen length and the shortest one
		r->divIdx = baseDiv + (uint8_t)(GetRngValue() % (REPEAT_NUM_DIVISIONS - baseDiv));
		r->reverse = (GetRngValue() % 4) == 0;

		// HY3: random pitch only if the pitch knob is off-centre;
		// the knob sets the maximum, the direction is random
		const float range = fabsf(br_semisFromParam(r->pitchParam));
		const float semis = (br_rnd01() * 2.f - 1.f) * range;
		r->speedStep = powf(2.f, semis / 12.f);

		const uint32_t pick = GetRngValue() % 4;
		if(pick == 0) r->shrink = 1.f;
		else if(pick == 1) r->shrink = 0.7f;
		else r->shrink = br_shrinkFromParam(r->shrinkParam);
	}
	else
	{
		r->divIdx = baseDiv;
		r->reverse = (r->mode == REPEAT_REV);
		r->speedStep = br_pitchStepFromParam(r->pitchParam);
		r->shrink = br_shrinkFromParam(r->shrinkParam);
	}

	r->baseLen = br_lenForDiv(r, r->divIdx, bpm);
	r->curLen = (float)r->baseLen;
	r->start = r->write;
	r->captured = 0;
	r->sliceValid = 0;
	r->state = REPEAT_CAPTURE;
}
//-----------------------------------------------------------------------
static void br_handleStep(BeatRepeat *r, float bpm)
{
	const float chance = r->chanceParam;
	const uint8_t win = (chance > 0.004f) && (br_rnd01() < chance || chance >= 0.996f);

	if(!win)
	{
		r->state = REPEAT_IDLE;	// back to live, r->mix fades out
		return;
	}

	if(r->state == REPEAT_IDLE)
	{
		if(r->mix <= 0.f)
			br_startCapture(r, bpm);
		// else: still fading out from the last repeat, start on the next step
	}
	else if(r->state == REPEAT_PLAY && r->mode == REPEAT_RND)
	{
		// occasionally re-cut the running slice into a new, shorter loop
		if((GetRngValue() % 100) < 35)
		{
			const uint8_t baseDiv = br_paramToDiv(r->rateParam);
			r->divIdx = baseDiv + (uint8_t)(GetRngValue() % (REPEAT_NUM_DIVISIONS - baseDiv));
			uint32_t len = br_lenForDiv(r, r->divIdx, bpm);
			if(len > r->baseLen) len = r->baseLen;
			r->curLen = (float)len;
			r->phase = 0.f;
			r->speed = 1.f;
			r->reverse = (GetRngValue() % 4) == 0;
		}
	}
	// REPEAT_CAPTURE or REPEAT_PLAY in fwd/rev: keep going
}
//-----------------------------------------------------------------------
static inline float br_read(BeatRepeat *r, uint32_t offset, float frac, uint32_t chOffset)
{
	uint32_t i0 = offset;
	uint32_t i1 = offset + 1;
	if(i1 >= r->baseLen) i1 = r->baseLen - 1;
	const float a = (float)r->buf[chOffset + ((r->start + i0) & r->mask)];
	const float b = (float)r->buf[chOffset + ((r->start + i1) & r->mask)];
	return a + (b - a) * frac;
}
//-----------------------------------------------------------------------
void BeatRepeat_process(BeatRepeat *r, const int16_t *fxBuffer, int16_t *out, uint16_t size,
		uint8_t channels, float dryWet, float bpm, uint8_t seqRunning)
{
	// --- clock: sequencer steps, or an internal 1/16 clock when stopped ---
	if(seqRunning)
	{
		r->samplesSinceStep = 0;
	}
	else
	{
		r->samplesSinceStep += size;
		if(r->samplesSinceStep >= (uint32_t)br_samplesPerStep(bpm))
		{
			r->samplesSinceStep = 0;
			BeatRepeat_onStep(r);
		}
	}

	while(r->pendingSteps)
	{
		r->pendingSteps--;
		br_handleStep(r, bpm);
	}

	const uint32_t half = r->half;

	for(uint16_t i = 0; i < size; i++)
	{
		const int16_t dryL = fxBuffer[2*i];
		const int16_t dryR = fxBuffer[2*i + 1];

		// --- record ---
		if(r->state != REPEAT_PLAY)
		{
			r->buf[r->write] = (FXSAMPLE_T)(dryL * (1.f/32768.f));
			r->buf[half + r->write] = (FXSAMPLE_T)(dryR * (1.f/32768.f));
			r->write = (r->write + 1) & r->mask;

			if(r->state == REPEAT_CAPTURE)
			{
				r->captured++;
				if(r->captured >= r->baseLen)
				{
					r->state = REPEAT_PLAY;
					r->sliceValid = 1;
					r->phase = 0.f;
				}
			}
		}

		// --- crossfade between live and repeat ---
		if(r->state == REPEAT_PLAY)
		{
			r->mix += REPEAT_MIX_STEP;
			if(r->mix > 1.f) r->mix = 1.f;
		}
		else
		{
			r->mix -= REPEAT_MIX_STEP;
			if(r->mix < 0.f) r->mix = 0.f;
		}

		float wetL = dryL;
		float wetR = dryR;

		// --- play the slice (also while fading out) ---
		if(r->sliceValid && r->mix > 0.f)
		{
			const float len = r->curLen;
			float pos = r->reverse ? (len - 1.f - r->phase) : r->phase;
			if(pos < 0.f) pos = 0.f;
			const uint32_t ip = (uint32_t)pos;
			const float frac = pos - (float)ip;

			// short fade at the slice edges
			float fade = REPEAT_FADE;
			if(fade > len * 0.25f) fade = len * 0.25f;
			float edge = r->phase;
			if(len - r->phase < edge) edge = len - r->phase;
			float g = (edge < fade) ? (edge / fade) : 1.f;

			float sL = br_read(r, ip, frac, 0) * 32767.f * g;
			float sR = br_read(r, ip, frac, half) * 32767.f * g;

			// DC blocker (~35 Hz): a loop shrunk to a few samples turns into a buzz
			// that can sit off-centre, this keeps it centred
			r->dcOutL = sL - r->dcInL + 0.995f * r->dcOutL;
			r->dcInL = sL;
			sL = r->dcOutL;
			r->dcOutR = sR - r->dcInR + 0.995f * r->dcOutR;
			r->dcInR = sR;
			sR = r->dcOutR;

			wetL = dryL + (sL - dryL) * r->mix;
			wetR = dryR + (sR - dryR) * r->mix;

			r->phase += r->speed;
			if(r->phase >= len)
			{
				r->phase = 0.f;
				// next loop: shorter and/or pitched
				r->curLen = len * r->shrink;
				if(r->curLen < REPEAT_MIN_LEN) r->curLen = REPEAT_MIN_LEN;
				r->speed *= r->speedStep;
				if(r->speed < REPEAT_MIN_SPEED) r->speed = REPEAT_MIN_SPEED;
				if(r->speed > REPEAT_MAX_SPEED) r->speed = REPEAT_MAX_SPEED;
			}
		}

		// --- dry/wet like the other FX, then add to the output ---
		const int32_t oL = (int32_t)(dryL + (wetL - dryL) * dryWet);
		const int32_t oR = (int32_t)(dryR + (wetR - dryR) * dryWet);

		if(channels == 2)
		{
			out[2*i]     = br_sat16(out[2*i] + oL);
			out[2*i + 1] = br_sat16(out[2*i + 1] + oR);
		}
		else
		{
			out[2*i] = br_sat16(out[2*i] + ((oL + oR) >> 1));
		}
	}
}
