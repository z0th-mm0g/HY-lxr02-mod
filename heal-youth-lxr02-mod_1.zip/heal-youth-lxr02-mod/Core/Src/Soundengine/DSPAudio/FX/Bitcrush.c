/*
 * Bitcrush.c
 *
 * Bit depth + sample rate reduction for the FX bus. See Bitcrush.h.
 * Part of the "Heal Youth" modified firmware for the Erica Synths LXR-02.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 *
 * This file is part of a modified version of the LXR firmware. It is licensed
 * under the GNU General Public License version 3, with the additional
 * permission and terms in NOTICE.md. See LICENSE and NOTICE.md in the root of
 * the repository.
 */

#include "Soundengine/DSPAudio/FX/Bitcrush.h"
#include <math.h>

uint32_t GetRngValue();

//-----------------------------------------------------------------------
static inline int16_t bc_sat16(int32_t x)
{
	if(x > 32767) return 32767;
	if(x < -32768) return -32768;
	return (int16_t)x;
}
//-----------------------------------------------------------------------
static inline int16_t bc_quantize(int16_t x, float step)
{
	if(step <= 1.f) return x;
	// round to the nearest step (mid-tread, keeps silence silent)
	const float q = floorf(x / step + 0.5f) * step;
	return bc_sat16((int32_t)q);
}
//-----------------------------------------------------------------------
void Bitcrush_init(Bitcrush *b)
{
	b->step = 1.f;
	b->rate = 1.f;
	b->jitter = 0.f;
	b->gain = 1.f;
	b->phase = 1.f;
	b->inc = 1.f;
	b->holdL = 0;
	b->holdR = 0;
}
//-----------------------------------------------------------------------
void Bitcrush_setBits(Bitcrush *b, float p)
{
	// 16 bit down to 1 bit
	b->step = powf(2.f, p * 15.f);
}
//-----------------------------------------------------------------------
void Bitcrush_setDownsample(Bitcrush *b, float p)
{
	// exponential: small values do little, the top end gets very crunchy
	b->rate = powf(2.f, -p * 6.f);	// 1 ... 1/64
}
//-----------------------------------------------------------------------
void Bitcrush_setJitter(Bitcrush *b, float p)
{
	b->jitter = p;
}
//-----------------------------------------------------------------------
void Bitcrush_setGain(Bitcrush *b, float p)
{
	b->gain = p * 2.f;
}
//-----------------------------------------------------------------------
void Bitcrush_process(Bitcrush *b, const int16_t *fxBuffer, int16_t *out, uint16_t size,
		uint8_t channels, float dryWet)
{
	for(uint16_t i = 0; i < size; i++)
	{
		const int16_t dryL = fxBuffer[2*i];
		const int16_t dryR = fxBuffer[2*i + 1];

		b->phase += b->inc;
		if(b->phase >= 1.f)
		{
			b->phase -= 1.f;
			b->holdL = bc_quantize(dryL, b->step);
			b->holdR = bc_quantize(dryR, b->step);

			// new hold time for the next sample, randomised by the jitter amount
			float inc = b->rate;
			if(b->jitter > 0.f)
			{
				const float r = (GetRngValue() % 1000) / 1000.f - 0.5f;	// -0.5..0.5
				inc *= 1.f + r * 1.8f * b->jitter;
				if(inc < 0.005f) inc = 0.005f;
			}
			b->inc = inc;
		}

		const float wetL = b->holdL * b->gain;
		const float wetR = b->holdR * b->gain;

		const int32_t oL = (int32_t)(dryL + (wetL - dryL) * dryWet);
		const int32_t oR = (int32_t)(dryR + (wetR - dryR) * dryWet);

		if(channels == 2)
		{
			out[2*i]     = bc_sat16(out[2*i] + oL);
			out[2*i + 1] = bc_sat16(out[2*i + 1] + oR);
		}
		else
		{
			out[2*i] = bc_sat16(out[2*i] + ((oL + oR) >> 1));
		}
	}
}
